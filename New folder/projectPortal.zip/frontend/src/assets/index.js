import { prism } from './animations/prism'
import { projectScreening } from './animations/projectScreening'

export {prism,projectScreening}