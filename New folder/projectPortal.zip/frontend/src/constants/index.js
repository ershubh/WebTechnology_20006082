import { assignedProjectsData } from "./Data/assignedProjectsData";
import { newProjectsData } from "./Data/newProjectsData";
import { DEGREES_COURSES } from "./DegreeList";
import { SUB_COURSES } from "./SubCourses";



export {assignedProjectsData,newProjectsData,DEGREES_COURSES,SUB_COURSES}