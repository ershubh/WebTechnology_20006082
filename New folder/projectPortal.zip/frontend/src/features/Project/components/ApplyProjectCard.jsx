import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { useState } from 'react';
import { Ratings } from './Ratings';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { selectAssignments } from '../../assignments/AssignmentSlice';
import { useDispatch, useSelector } from 'react-redux';
import { Delete } from '@mui/icons-material';
import { IconButton, MenuItem, Select, Stack, TextField } from '@mui/material';
import { deleteProjectByIdAsync, updateProjectByIdAsync } from '../ProjectSlice';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';


export const ProjectCard=({projectTitle,supervisorName,difficultyRating,problemStatement,postedDateTime,projectid,staff=false})=> {


  const [isExpanded,setIsExpanded]=useState(false)

  const [isEditing,setIsEditing]=useState(false)

  const shortText=problemStatement.slice(0,100)
  const dispatch=useDispatch()
  const navigate=useNavigate()

  const assignments=useSelector(selectAssignments)
  console.log(assignments)
  const currentDate = new Date();

  const timeDifference = new Date(postedDateTime) - currentDate

  const hoursDifference = Math.floor(timeDifference / (1000 * 60 * 60));

  const isProjectAlreadyApplied = assignments.some(item => item.project._id === projectid);

  const handleNavigate=(projectid)=>{
    if(!staff){
      navigate(`/project-details/${projectid}`)
    }
  }


  const [editedProjectValue,setProjectValue]=useState({
    projectTitle:"",
    description:"",
    difficultyRating:""
  })

  const handleEdit=(index)=>{

    setIsEditing(true)
    setProjectValue({projectTitle:projectTitle,description:problemStatement,difficultyRating:difficultyRating})
  }

  const handleProjectUpdate=()=>{
    const update={...editedProjectValue,_id:projectid}
    dispatch(updateProjectByIdAsync(update))
    setIsEditing(false)
  }

  const handleChange=(e)=>{
    setProjectValue({...editedProjectValue,[e.target.name]:e.target.value})
  }


  return (
    <Card sx={{width:600,mt:2,cursor:'pointer'}} onClick={()=>handleNavigate(projectid)}>
      <CardContent>
        <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
          {Math.abs(hoursDifference)===0?"posted just now":`posted ${Math.abs(hoursDifference)} hours ago`}
        </Typography>
        <Stack flexDirection={'row'} justifyContent={'space-between'}>

          {
            isEditing?(<TextField name='projectTitle' onChange={(e)=>handleChange(e)} value={editedProjectValue.projectTitle}/>):(
        <Typography variant="h5" component="div">
          {projectTitle}
        </Typography>

            )
          }
        {
        staff && 
        <Stack flexDirection={'row-reverse'}>
        <IconButton onClick={()=>dispatch(deleteProjectByIdAsync(projectid))}><Delete/></IconButton>

        {
          isEditing?(<IconButton onClick={handleProjectUpdate}><CheckCircleIcon></CheckCircleIcon></IconButton>):(<IconButton onClick={handleEdit}><EditOutlinedIcon/></IconButton>)
        }
        
        </Stack>
        }

        </Stack>
        <Typography sx={{ mb: 1.5 }} color="text.secondary">
          {supervisorName}
        </Typography>

        {isEditing?(<TextField name='description' onChange={(e)=>handleChange(e)} multiline rows={4} value={editedProjectValue.description} />):(

        <Typography gutterBottom variant="body2">
          {isExpanded?problemStatement:shortText}
          {isExpanded===true?(
            <Typography sx={{cursor:"pointer"}} onClick={()=>setIsExpanded((prev)=>!prev)}>show less</Typography>
          ):(
            <Typography sx={{cursor:"pointer"}} onClick={()=>setIsExpanded((prev)=>!prev)}>...read more</Typography>
          )}
        </Typography>
        )}



        <Typography variant='body2' fontWeight={300} mt={3}>Difficulty Rating</Typography>
        {
          isEditing?(
            <Select name='difficultyRating' onChange={(e)=>handleChange(e)} value={editedProjectValue.difficultyRating}>
              <MenuItem value={1}>1</MenuItem>
              <MenuItem value={2}>2</MenuItem>
              <MenuItem value={3}>3</MenuItem>
              <MenuItem value={4}>4</MenuItem>
              <MenuItem value={5}>5</MenuItem>
            </Select>
          ):(

            <Ratings value={difficultyRating}/>
          )
        }


      </CardContent>
      <CardActions>
        {
          staff?(
            <Button variant='contained' onClick={handleEdit}>Edit</Button>
          ):(
            
            <Button size="small" variant='contained'>{isProjectAlreadyApplied?"Applied✅":"View Project"}</Button>
          )
        }
      </CardActions>
    </Card>
  );
}