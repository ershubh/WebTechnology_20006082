import { Box, Stack } from "@mui/material"
import { Leftbar } from "../../../components/Leftbar"
import { ProjectCard } from "./ApplyProjectCard"


import React, { useEffect } from 'react'
import { useDispatch, useSelector } from "react-redux"
import { fetchAllProjectAsync, selectAllProjects } from "../ProjectSlice"
import { selectLoggedInUser } from "../../auth/AuthSlice"
import BasicSpeedDial from "./BasicSpeedDial"
import { selectAssignments } from "../../assignments/AssignmentSlice"

export const ApplyProjectList = () => {

  const dispatch=useDispatch()
  const loggedInUser=useSelector(selectLoggedInUser)

  const newProjectsData=useSelector(selectAllProjects)
  console.log(newProjectsData)



  useEffect(()=>{dispatch(fetchAllProjectAsync())},[dispatch])

  return (

    <Stack sx={{width:'100vw',height:"100vw",minHeight: "calc(100vh - 6rem)",justifyContent:'center',alignItems:'center',flexDirection:"row",display:'flex',p:1}}>

  <Stack width={"70%"} height={"100%"}  justifyContent={'space-evenly'} alignItems={'center'} flexDirection={'row'}>
    

    {/* leftbar */}
    <Box flex={'20%'} height={"100%"}>
        <Leftbar/>
    </Box>

    
    {/* apply cards shown here */}
    <Stack flex={'80%'} justifyContent={'flex-start'} alignItems={'center'} height={'100%'}>

      <Stack width={'100%'} p={2} justifyContent={'center'} alignItems={'center'}>
        {
          newProjectsData &&  newProjectsData.map((data)=>{
            return <ProjectCard projectid={data._id}  projectTitle={data.projectTitle} supervisorName={data.supervisorName} postedDateTime={data.postedDateTime} problemStatement={data.description} difficultyRating={data.difficultyRating} key={data._id}/>
          })
         
        }
      </Stack>
    </Stack>


    <Stack sx={{position:"fixed",right:'2rem',bottom:'2rem'}}>
    {loggedInUser?.role==='staff' && <BasicSpeedDial/>}  
    </Stack>
    
    
  </Stack>

</Stack>
  )
}

