import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, useParams } from 'react-router-dom'
import { fetchProjectByIdAsync, selectSelectProject } from '../ProjectSlice'
import { Button, Card, CardActions, CardContent, Stack, Typography } from '@mui/material'
import { Ratings } from './Ratings'
import { createAssignmentAsync, selectAssignments } from '../../assignments/AssignmentSlice'
import { selectLoggedInUser } from '../../auth/AuthSlice'

export const ProjectDetails = () => {

    const project=useSelector(selectSelectProject)
    const {id}=useParams()

    const loggedInUser=useSelector(selectLoggedInUser)

    const dispatch=useDispatch()

    const [isExpanded,setIsExpanded]=useState(true)
  const shortText=project?.description.slice(0,100)
  const navigate=useNavigate()

  const assignments=useSelector(selectAssignments)
  console.log(assignments)

  const isProjectAlreadyApplied = assignments.some(project => project.project._id === id);

  const currentDate = new Date();

  const timeDifference = new Date(project?.postedDateTime) - currentDate

  const hoursDifference = Math.floor(timeDifference / (1000 * 60 * 60));


    useEffect(()=>{
        dispatch(fetchProjectByIdAsync(id))
    },[])


  return (
    <Stack sx={{width:"100vw",justifyContent:"flex-start",alignItems:'center'}}>
    
    <Stack width={'70%'}>
    <Stack sx={{width:'100%',mt:2,cursor:'pointer'}}>
            <Card >
            <CardContent>
            <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                {Math.abs(hoursDifference)===0?"posted just now":`posted ${Math.abs(hoursDifference)} hours ago`}
            </Typography>
            <Typography variant="h5" component="div">
                {project?.projectTitle}
            </Typography>
            <Typography sx={{ mb: 1.5 }} color="text.secondary">
                {project?.supervisorName}
            </Typography>
            <Typography gutterBottom variant="body2">
                {isExpanded?project?.description:shortText}
                {isExpanded===true?(
                <Typography sx={{cursor:"pointer"}} onClick={()=>setIsExpanded((prev)=>!prev)}>show less</Typography>
                ):(
                <Typography sx={{cursor:"pointer"}} onClick={()=>setIsExpanded((prev)=>!prev)}>...read more</Typography>
                )}
            </Typography>



            <Typography variant='body2' fontWeight={300} mt={3}>Difficulty Rating</Typography>
            
            <Ratings value={project?.difficultyRating}/>


            </CardContent>
            <CardActions>
            <Button size="large" disabled={isProjectAlreadyApplied} onClick={()=>(dispatch(createAssignmentAsync({student:loggedInUser?._id,project:id})))} variant='contained'>
                {isProjectAlreadyApplied?"Applied✅":'apply'}
            </Button>
            </CardActions>
        </Card>
    </Stack>

    <Stack mt={2} alignSelf={'flex-start'} spacing={2}>
        <Typography variant='h5' fontWeight={400}>Posted by</Typography>
        <Stack spacing={1}>
        <Typography>Name - {project?.supervisorName}</Typography>
        <Typography>Email -{project?.supervisorEmail}</Typography></Stack>
    </Stack>

    </Stack>
    </Stack>
  )
}
