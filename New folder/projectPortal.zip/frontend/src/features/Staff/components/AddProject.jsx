import { Box, Button, FormControl, InputLabel, MenuItem, Select, Stack, TextField, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { selectStaffInfo } from '../StaffSlice';
import { addProjectAsync } from '../../Project/ProjectSlice';
import { Leftbar } from '../../../components/Leftbar';

export const AddProject = () => {

    const [buttontxt,Setbuttontxt]=useState("Add Project")
    const { register,handleSubmit,watch,reset,formState: { errors },} = useForm()
    const staff=useSelector(selectStaffInfo)
    const dispatch=useDispatch()



    useEffect(()=>{
        setTimeout(() => {
            Setbuttontxt('add project')
        }, 1000);
    },[buttontxt])


  return (
    <Stack width={'100vw'} height={'calc(100vh - 8rem)'} justifyContent={'center'} alignItems={'center'}>

            
        <Stack width={"70%"} height={"100%"}  justifyContent={'space-evenly'} alignItems={'center'} flexDirection={'row'}>

            <Box flex={"20%"}  bgcolor={'red'} height={"100%"}>
                <Leftbar/>
            </Box>



            <Stack width={'70rem'} spacing={2} component={'form'} noValidate onSubmit={handleSubmit((data)=>{
                const finalData={...data,supervisorEmail:staff.email,supervisorName:staff.name,staff:staff._id}
                
                dispatch(addProjectAsync(finalData))
                Setbuttontxt("Added")
                reset()


            })}>
                <TextField {...register("projectTitle",{required:"title is required"})} placeholder='Project Title'></TextField>
                <TextField {...register("description",{required:"desciption is required"})} placeholder='Description'></TextField>
                <FormControl>

                <InputLabel>Select Difficulty Rating</InputLabel>
                <Select {...register("difficultyRating",{required:"description is required"})}>
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={2}>2</MenuItem>
                    <MenuItem value={3}>3</MenuItem>
                    <MenuItem value={4}>4</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                </Select>


                </FormControl>

                <Button variant='contained' type='submit'>{buttontxt}</Button>
            </Stack>
            
        </Stack>
    </Stack>
  )
}
