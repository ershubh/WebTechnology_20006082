import React from 'react'
import { Logout } from '../features/auth/components/Logout'

export const LogoutPage = () => {
  return (
    <><Logout/></>
  )
}
